import dotenv from 'dotenv';
dotenv.config();
import express, { json, urlencoded } from 'express';
import { delete_user_by_id, list_all_users, login, register } from './controllers/AuthController.mjs';
import { create_task, get_task_by_id, list_all_tasks, list_tasks_by_user, update_task, delete_tasks, delete_task_by_id } from './controllers/TasksController.mjs';
import jwt from 'jsonwebtoken';
import { createServer } from 'node:http';
import cors from 'cors'

const app = express();

app.use(cors())
app.use(json())
app.use(urlencoded({ extended: true }))


app.set('view engine', 'ejs');

app.get('/', (req, res) => { return res.send('Hello World!') })

app.post('/delete_user_by_id/:id', authenticateToken, delete_user_by_id)
app.get('/list_all_users', authenticateToken, list_all_users)
app.post('/login', login)
app.post('/register', register)
app.post('/createTask', authenticateToken, create_task)
app.get('/listTasks', authenticateToken, list_all_tasks)
app.get('/listTasksByUser', authenticateToken, list_tasks_by_user)
app.get('/getTask/:id', authenticateToken, get_task_by_id)
app.post('/updateTask/:id', authenticateToken, update_task)
app.post('/deleteTasks', authenticateToken, delete_tasks)
app.post('/delete_task_by_id/:id', authenticateToken, delete_task_by_id)

async function authenticateToken(req, res, next) {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
        return res.status(401).send('Access token missing');
    }

    const token = authHeader.split(' ')[1];
    try {

        jwt.verify(token, process.env.SECRET_KEY, (err, user) => {
            if (err) {
                return res.status(403).send('Invalid token');
            }
            
            req.user = user;
            next();

        });
    } catch (err) {
        console.error('Error checking token:', err);
        res.status(500).send('Server Error');
    }
}


app.listen(process.env.PORT, () => {
    console.log(`Server on port ${process.env.PORT}`);
  });